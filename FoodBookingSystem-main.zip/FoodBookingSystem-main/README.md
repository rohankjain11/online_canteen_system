# Online Food Booking System
Online Food Booking System is an online booking system that allows students to skip long lunch lines by pre-ordering their food from anywhere using the internet or a mobile device.


## Users and their Functionality
1. Admin can handle the functionalities like :
     * add new food items
     * user details are also viewable to admin. 
     * edit/delete food items
     * view order details and update the delivery status of food.  
2. User(Student):
The registered user can access :
     * the account with valid credentials.
     * Surf the food items
     * Order items
     * View food details

## Technologies
***
A list of technologies used within the project:
* HTML
* CSS
* Java Script
* PHP
